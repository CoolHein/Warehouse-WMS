# Sound Assets

This folder should contain the following sound files:
- pick-success.mp3
- error-buzz.mp3
- level-up.mp3
- scan-beep.mp3
- achievement-unlock.mp3
- pack-complete.mp3

These are placeholder filenames. The actual MP3 files need to be added to provide auditory feedback.